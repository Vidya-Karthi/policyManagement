// response object from userInfo
    export interface IUserDetails {
        userName: string;
        firstName: string;
        LastName: string;
        emailId: string;
        dealerCode: string;
        regionCode: string;
        displayName: string;
        authorities: any;
      }


